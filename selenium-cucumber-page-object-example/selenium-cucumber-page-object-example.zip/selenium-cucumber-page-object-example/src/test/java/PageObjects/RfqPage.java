package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.BaseClass;

public class RfqPage extends BaseClass {

	public RfqPage(WebDriver driver, WebDriverWait wait) {
		super(driver, wait);
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "flt-semantics[aria-label='RFQ']")

	WebElement RFQLink;

	public void clickOnRfqLink() throws InterruptedException {

		new Actions(driver).moveToElement(RFQLink).click().build().perform();
	}

	public boolean isDisplayedCreate() {
		WaitUntilElementVisible(CreateRFQ);
		return CreateRFQ.isDisplayed();

	}

	@FindBy(css = "flt-semantics[aria-label='Create RFQ']")
	WebElement CreateRFQ;

	public void clickoncreaterfq() {
		WaitUntilElementVisible(CreateRFQ);
		CreateRFQ.click();

	}

	public boolean isDisplayedProdCategory() {
		WaitUntilElementVisible(ProdCategory);
		return ProdCategory.isDisplayed();

	}

	@FindBy(css = "flt-semantics[aria-label='--Select Product Category--']")
	WebElement ProdCategory;

	public void selectProduct() {
		WaitUntilElementVisible(ProdCategory);
		ProdCategory.click();
	}
	
	public boolean isDisplayedEB() {
		WaitUntilElementVisible(EB);
		return EB.isDisplayed();
	}

	@FindBy(css = "flt-semantics[aria-label='EB']")
	WebElement EB;

	public void SelectEB() {
		WaitUntilElementVisible(EB);
		EB.click();
	}
	

	

	@FindBy(css = "flt-semantics[aria-label='NON-EB']")
	WebElement NonEb;

	public void SelectNonEb() {
		NonEb.click();
	}

	@FindBy(css = "flt-semantics[aria-label='----Select Product type-----']")
	WebElement ProdType;

	public void SelectProdType() {
		WaitUntilElementVisible(ProdType);
		ProdType.click();
	}

	@FindBy(css = "flt-semantics[aria-label='Group Health Insurance (GHI)']")
	WebElement GHI;

	public void ghi() {
//		WaitUntilElementVisible(GHI);
		GHI.click();
	}

	@FindBy(css = "flt-semantics[aria-label='------Select Policy Type------']")
	WebElement Policytype;

	public void SelectPolicyType() {
		WaitUntilElementVisible(Policytype);
		Policytype.click();
	}

	@FindBy(css = "flt-semantics[aria-label='Fresh']")
	WebElement Fresh;

	public void SelectFresh() {
		WaitUntilElementVisible(Fresh);
		Fresh.click();
	}

	@FindBy(css = "flt-semantics[aria-label='Submit']")
	WebElement ClickButton;

	public void Submit() {
		ClickButton.click();
	}
	

}
